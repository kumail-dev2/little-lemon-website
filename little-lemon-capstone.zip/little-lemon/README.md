# Little Lemon – React Capstone Project

A fully functional React web application for the Little Lemon restaurant,
built for the Meta Front-End Developer Capstone course.

## Project Structure

```
src/
├── components/
│   ├── Header.jsx          # Site header with NavLink navigation
│   ├── Header.css
│   ├── BookingForm.jsx      # ✅ Child component – receives availableTimes as prop
│   └── BookingForm.css
├── pages/
│   ├── HomePage.jsx         # Hero, Specials, Testimonials, About snippet
│   ├── BookingPage.jsx      # ✅ Parent – manages availableTimes state with useReducer
│   ├── ConfirmedBooking.jsx # Confirmation page after successful booking
│   ├── MenuPage.jsx
│   ├── AboutPage.jsx
│   └── Footer.jsx
├── utils/
│   └── api.js              # fetchAPI + submitAPI mock functions
├── tests/
│   ├── BookingForm.test.jsx # 22 unit tests (rendering + validation + UX)
│   └── api.test.js         # 8 unit tests for API functions
├── App.js                  # React Router routes
└── index.js
```

## Peer Review Checklist

| Criterion | Status |
|---|---|
| UI matches Figma / brand guide | ✅ |
| Responsive (mobile + desktop) | ✅ |
| BookingForm is a child component | ✅ |
| availableTimes managed in parent via useReducer | ✅ |
| Client-side validation on all required fields | ✅ |
| Unit tests for form + API | ✅ 30 tests |

## Getting Started

```bash
npm install
npm start
```

## Running Tests

```bash
npm test
```

## Building for Production

```bash
npm run build
```
