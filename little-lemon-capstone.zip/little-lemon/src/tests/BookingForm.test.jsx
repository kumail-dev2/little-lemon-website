import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import BookingForm from '../components/BookingForm';

const mockTimes = ['17:00', '18:00', '19:00', '20:00'];
const mockOnDateChange = jest.fn();
const mockOnSubmit = jest.fn();

const defaultProps = {
  availableTimes: mockTimes,
  onDateChange: mockOnDateChange,
  onSubmit: mockOnSubmit,
  isSubmitting: false,
};

function renderForm(props = {}) {
  return render(<BookingForm {...defaultProps} {...props} />);
}

describe('BookingForm – rendering', () => {
  test('renders the form title', () => {
    renderForm();
    expect(screen.getByText('Reserve a Table')).toBeInTheDocument();
  });

  test('renders all required fields', () => {
    renderForm();
    expect(screen.getByLabelText(/first name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/last name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/date/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/time/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/number of guests/i)).toBeInTheDocument();
  });

  test('renders available times as select options', () => {
    renderForm();
    const select = screen.getByLabelText(/time/i);
    mockTimes.forEach(time => {
      expect(select).toContainHTML(`<option value="${time}">${time}</option>`);
    });
  });

  test('renders submit button with correct text', () => {
    renderForm();
    expect(screen.getByRole('button', { name: /confirm reservation/i })).toBeInTheDocument();
  });

  test('renders submit button as disabled when isSubmitting', () => {
    renderForm({ isSubmitting: true });
    const btn = screen.getByRole('button', { name: /confirming/i });
    expect(btn).toBeDisabled();
  });

  test('renders occasion dropdown with multiple options', () => {
    renderForm();
    const select = screen.getByLabelText(/occasion/i);
    expect(select).toBeInTheDocument();
    expect(screen.getByRole('option', { name: /birthday/i })).toBeInTheDocument();
    expect(screen.getByRole('option', { name: /anniversary/i })).toBeInTheDocument();
  });
});

describe('BookingForm – validation', () => {
  test('shows error when first name is empty on submit', async () => {
    renderForm();
    fireEvent.click(screen.getByRole('button', { name: /confirm reservation/i }));
    await waitFor(() => {
      expect(screen.getByText('First name is required.')).toBeInTheDocument();
    });
  });

  test('shows error when last name is empty on submit', async () => {
    renderForm();
    fireEvent.click(screen.getByRole('button', { name: /confirm reservation/i }));
    await waitFor(() => {
      expect(screen.getByText('Last name is required.')).toBeInTheDocument();
    });
  });

  test('shows error when email is empty on submit', async () => {
    renderForm();
    fireEvent.click(screen.getByRole('button', { name: /confirm reservation/i }));
    await waitFor(() => {
      expect(screen.getByText('Email is required.')).toBeInTheDocument();
    });
  });

  test('shows error for invalid email format', async () => {
    renderForm();
    const emailInput = screen.getByLabelText(/email address/i);
    await userEvent.type(emailInput, 'notanemail');
    fireEvent.blur(emailInput);
    await waitFor(() => {
      expect(screen.getByText('Please enter a valid email address.')).toBeInTheDocument();
    });
  });

  test('shows error when time is not selected on submit', async () => {
    renderForm();
    const firstName = screen.getByLabelText(/first name/i);
    const lastName = screen.getByLabelText(/last name/i);
    const email = screen.getByLabelText(/email address/i);
    await userEvent.type(firstName, 'Jane');
    await userEvent.type(lastName, 'Doe');
    await userEvent.type(email, 'jane@example.com');
    fireEvent.click(screen.getByRole('button', { name: /confirm reservation/i }));
    await waitFor(() => {
      expect(screen.getByText('Please select a time slot.')).toBeInTheDocument();
    });
  });

  test('does not call onSubmit when form is invalid', async () => {
    renderForm();
    fireEvent.click(screen.getByRole('button', { name: /confirm reservation/i }));
    await waitFor(() => {
      expect(mockOnSubmit).not.toHaveBeenCalled();
    });
  });

  test('calls onSubmit when form is valid', async () => {
    renderForm();
    await userEvent.type(screen.getByLabelText(/first name/i), 'Jane');
    await userEvent.type(screen.getByLabelText(/last name/i), 'Doe');
    await userEvent.type(screen.getByLabelText(/email address/i), 'jane@example.com');
    await userEvent.selectOptions(screen.getByLabelText(/time/i), '18:00');
    fireEvent.click(screen.getByRole('button', { name: /confirm reservation/i }));
    await waitFor(() => {
      expect(mockOnSubmit).toHaveBeenCalled();
    });
  });

  test('shows validation errors inline next to fields', async () => {
    renderForm();
    fireEvent.blur(screen.getByLabelText(/first name/i));
    await waitFor(() => {
      expect(screen.getByText('First name is required.')).toBeInTheDocument();
    });
  });

  test('clears error after valid input is entered', async () => {
    renderForm();
    const emailInput = screen.getByLabelText(/email address/i);
    await userEvent.type(emailInput, 'bad-email');
    fireEvent.blur(emailInput);
    await waitFor(() => {
      expect(screen.getByText('Please enter a valid email address.')).toBeInTheDocument();
    });
    await userEvent.clear(emailInput);
    await userEvent.type(emailInput, 'good@email.com');
    await waitFor(() => {
      expect(screen.queryByText('Please enter a valid email address.')).not.toBeInTheDocument();
    });
  });
});

describe('BookingForm – guest counter', () => {
  test('guest count starts at 2', () => {
    renderForm();
    const input = screen.getByLabelText(/number of guests/i);
    expect(input.value).toBe('2');
  });

  test('increases guest count when + is clicked', async () => {
    renderForm();
    const increaseBtn = screen.getByRole('button', { name: /increase guests/i });
    await userEvent.click(increaseBtn);
    const input = screen.getByLabelText(/number of guests/i);
    expect(input.value).toBe('3');
  });

  test('decreases guest count when − is clicked', async () => {
    renderForm();
    const decreaseBtn = screen.getByRole('button', { name: /decrease guests/i });
    await userEvent.click(decreaseBtn);
    const input = screen.getByLabelText(/number of guests/i);
    expect(input.value).toBe('1');
  });

  test('decrease button is disabled when guests = 1', async () => {
    renderForm();
    const decreaseBtn = screen.getByRole('button', { name: /decrease guests/i });
    await userEvent.click(decreaseBtn); // goes to 1
    expect(decreaseBtn).toBeDisabled();
  });

  test('increase button is disabled when guests = 10', async () => {
    renderForm();
    const increaseBtn = screen.getByRole('button', { name: /increase guests/i });
    for (let i = 0; i < 8; i++) {
      await userEvent.click(increaseBtn); // 2 → 10
    }
    expect(increaseBtn).toBeDisabled();
  });
});

describe('BookingForm – date change', () => {
  test('calls onDateChange when date input changes', () => {
    renderForm();
    const dateInput = screen.getByLabelText(/date/i);
    fireEvent.change(dateInput, { target: { name: 'date', value: '2024-12-25' } });
    expect(mockOnDateChange).toHaveBeenCalled();
  });
});
