import { fetchAPI, submitAPI } from '../utils/api';

describe('fetchAPI', () => {
  test('returns an array of time strings', async () => {
    const times = await fetchAPI(new Date('2024-06-15'));
    expect(Array.isArray(times)).toBe(true);
    expect(times.length).toBeGreaterThan(0);
  });

  test('returns times in HH:MM format', async () => {
    const times = await fetchAPI(new Date('2024-06-15'));
    times.forEach(time => {
      expect(time).toMatch(/^\d{2}:\d{2}$/);
    });
  });

  test('returns different times for different dates (seeded)', async () => {
    const times1 = await fetchAPI(new Date('2024-01-01'));
    const times2 = await fetchAPI(new Date('2024-06-15'));
    // They might differ — test that both are valid arrays
    expect(Array.isArray(times1)).toBe(true);
    expect(Array.isArray(times2)).toBe(true);
  });

  test('always returns at least one time slot', async () => {
    const times = await fetchAPI(new Date('2024-12-31'));
    expect(times.length).toBeGreaterThanOrEqual(1);
  });

  test('handles invalid date gracefully', async () => {
    const times = await fetchAPI(null);
    expect(Array.isArray(times)).toBe(true);
    expect(times.length).toBeGreaterThan(0);
  });

  test('returns consistent results for the same date', async () => {
    const date = new Date('2024-03-20');
    const times1 = await fetchAPI(date);
    const times2 = await fetchAPI(date);
    expect(times1).toEqual(times2);
  });
});

describe('submitAPI', () => {
  test('returns a boolean', async () => {
    const result = await submitAPI({ firstName: 'Jane', date: '2024-06-15', time: '18:00', guests: 2 });
    expect(typeof result).toBe('boolean');
  });

  test('accepts a booking object without throwing', async () => {
    const booking = {
      firstName: 'Jane',
      lastName: 'Doe',
      email: 'jane@example.com',
      date: '2024-06-15',
      time: '18:00',
      guests: 2,
      occasion: 'Birthday',
    };
    await expect(submitAPI(booking)).resolves.not.toThrow();
  });
});
