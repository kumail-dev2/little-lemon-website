import React from 'react';
import { NavLink } from 'react-router-dom';
import './Header.css';

const LemonLogo = () => (
  <svg className="logo-icon" viewBox="0 0 60 70" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <ellipse cx="30" cy="42" rx="22" ry="26" fill="#495E57"/>
    <ellipse cx="30" cy="40" rx="18" ry="22" fill="#F4CE14"/>
    <path d="M30 18 C30 18 20 8 30 2 C40 8 30 18 30 18Z" fill="#495E57"/>
    <line x1="30" y1="18" x2="30" y2="58" stroke="#495E57" strokeWidth="1.5"/>
    <line x1="30" y1="35" x2="20" y2="27" stroke="#495E57" strokeWidth="1"/>
    <line x1="30" y1="42" x2="40" y2="34" stroke="#495E57" strokeWidth="1"/>
  </svg>
);

function Header() {
  return (
    <header className="site-header">
      <div className="header-inner">
        <NavLink to="/" className="logo">
          <LemonLogo />
          <span className="logo-text">LITTLE LEMON</span>
        </NavLink>
      </div>
      <nav className="main-nav" aria-label="Main navigation">
        <ul>
          <li><NavLink to="/" end>Home</NavLink></li>
          <li><NavLink to="/menu">Menu</NavLink></li>
          <li><NavLink to="/booking">Book a Table</NavLink></li>
          <li><NavLink to="/about">About</NavLink></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
