import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <Link to="/" className="footer-logo" aria-label="Little Lemon Home">
          <svg className="logo-icon-small" viewBox="0 0 60 70" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <ellipse cx="30" cy="42" rx="22" ry="26" fill="#495E57"/>
            <ellipse cx="30" cy="40" rx="18" ry="22" fill="#F4CE14"/>
            <path d="M30 18 C30 18 20 8 30 2 C40 8 30 18 30 18Z" fill="#495E57"/>
            <line x1="30" y1="18" x2="30" y2="58" stroke="#495E57" strokeWidth="1.5"/>
            <line x1="30" y1="35" x2="20" y2="27" stroke="#495E57" strokeWidth="1"/>
            <line x1="30" y1="42" x2="40" y2="34" stroke="#495E57" strokeWidth="1"/>
          </svg>
        </Link>
        <nav aria-label="Footer navigation">
          <ul className="footer-links">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/menu">Menu</Link></li>
            <li><Link to="/booking">Reservations</Link></li>
            <li><Link to="/about">About</Link></li>
          </ul>
        </nav>
        <div className="footer-contact">
          <p><strong>Address:</strong> 123 Lemon St, Chicago, IL</p>
          <p><strong>Phone:</strong> (312) 555-0199</p>
          <p><strong>Email:</strong> hello@littlelemon.com</p>
        </div>
        <div className="footer-copy">
          <p>Copyright Little Lemon &copy; {new Date().getFullYear()}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
