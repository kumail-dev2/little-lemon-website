import React, { useState } from 'react';
import './BookingForm.css';

/**
 * BookingForm – child component.
 * Receives availableTimes and dispatch from parent (BookingPage).
 * Manages its own local form state and validation.
 */
function BookingForm({ availableTimes, onDateChange, onSubmit, isSubmitting }) {
  const today = new Date().toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    date: today,
    time: '',
    guests: 2,
    occasion: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    specialRequests: '',
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  // Validation rules
  const validate = (data) => {
    const errs = {};
    if (!data.firstName.trim()) errs.firstName = 'First name is required.';
    if (!data.lastName.trim()) errs.lastName = 'Last name is required.';
    if (!data.email.trim()) {
      errs.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errs.email = 'Please enter a valid email address.';
    }
    if (data.phone && !/^[0-9+\-\s()]{7,15}$/.test(data.phone)) {
      errs.phone = 'Please enter a valid phone number.';
    }
    if (!data.date) errs.date = 'Please select a date.';
    if (!data.time) errs.time = 'Please select a time slot.';
    if (!data.guests || data.guests < 1 || data.guests > 10) {
      errs.guests = 'Guests must be between 1 and 10.';
    }
    return errs;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updated = { ...formData, [name]: value };
    setFormData(updated);
    setTouched((prev) => ({ ...prev, [name]: true }));

    if (name === 'date') {
      onDateChange(new Date(value));
      // Reset time when date changes
      setFormData((prev) => ({ ...prev, date: value, time: '' }));
    }

    // Live validation for touched fields
    const errs = validate(updated);
    setErrors(errs);
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors(validate(formData));
  };

  const handleGuestChange = (delta) => {
    const newVal = Math.min(10, Math.max(1, Number(formData.guests) + delta));
    const updated = { ...formData, guests: newVal };
    setFormData(updated);
    setErrors(validate(updated));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Mark all fields touched
    const allTouched = Object.keys(formData).reduce((acc, k) => ({ ...acc, [k]: true }), {});
    setTouched(allTouched);

    const errs = validate(formData);
    setErrors(errs);

    if (Object.keys(errs).length === 0) {
      onSubmit(formData);
    }
  };

  const fieldError = (name) => touched[name] && errors[name];

  return (
    <form
      className="booking-form"
      onSubmit={handleSubmit}
      noValidate
      aria-label="Table booking form"
    >
      <h2 className="form-title">Reserve a Table</h2>
      <p className="form-subtitle">Fill in the details below and we'll confirm your reservation.</p>

      {/* Personal Details */}
      <fieldset className="form-section">
        <legend>Your Details</legend>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="firstName">First Name <span aria-hidden="true">*</span></label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              value={formData.firstName}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Jane"
              aria-required="true"
              aria-describedby={fieldError('firstName') ? 'firstName-error' : undefined}
              aria-invalid={!!fieldError('firstName')}
              className={fieldError('firstName') ? 'input-error' : ''}
              autoComplete="given-name"
            />
            {fieldError('firstName') && (
              <span id="firstName-error" className="error-msg" role="alert">{errors.firstName}</span>
            )}
          </div>
          <div className="form-group">
            <label htmlFor="lastName">Last Name <span aria-hidden="true">*</span></label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              value={formData.lastName}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Doe"
              aria-required="true"
              aria-describedby={fieldError('lastName') ? 'lastName-error' : undefined}
              aria-invalid={!!fieldError('lastName')}
              className={fieldError('lastName') ? 'input-error' : ''}
              autoComplete="family-name"
            />
            {fieldError('lastName') && (
              <span id="lastName-error" className="error-msg" role="alert">{errors.lastName}</span>
            )}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="email">Email Address <span aria-hidden="true">*</span></label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="jane@example.com"
              aria-required="true"
              aria-describedby={fieldError('email') ? 'email-error' : undefined}
              aria-invalid={!!fieldError('email')}
              className={fieldError('email') ? 'input-error' : ''}
              autoComplete="email"
            />
            {fieldError('email') && (
              <span id="email-error" className="error-msg" role="alert">{errors.email}</span>
            )}
          </div>
          <div className="form-group">
            <label htmlFor="phone">Phone Number</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="+1 (312) 555-0199"
              aria-describedby={fieldError('phone') ? 'phone-error' : undefined}
              aria-invalid={!!fieldError('phone')}
              className={fieldError('phone') ? 'input-error' : ''}
              autoComplete="tel"
            />
            {fieldError('phone') && (
              <span id="phone-error" className="error-msg" role="alert">{errors.phone}</span>
            )}
          </div>
        </div>
      </fieldset>

      {/* Booking Details */}
      <fieldset className="form-section">
        <legend>Booking Details</legend>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="date">Date <span aria-hidden="true">*</span></label>
            <input
              id="date"
              name="date"
              type="date"
              value={formData.date}
              min={today}
              onChange={handleChange}
              onBlur={handleBlur}
              aria-required="true"
              aria-describedby={fieldError('date') ? 'date-error' : undefined}
              aria-invalid={!!fieldError('date')}
              className={fieldError('date') ? 'input-error' : ''}
            />
            {fieldError('date') && (
              <span id="date-error" className="error-msg" role="alert">{errors.date}</span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="time">Time <span aria-hidden="true">*</span></label>
            <select
              id="time"
              name="time"
              value={formData.time}
              onChange={handleChange}
              onBlur={handleBlur}
              aria-required="true"
              aria-describedby={fieldError('time') ? 'time-error' : undefined}
              aria-invalid={!!fieldError('time')}
              className={fieldError('time') ? 'input-error' : ''}
            >
              <option value="">Select a time</option>
              {availableTimes.map((slot) => (
                <option key={slot} value={slot}>{slot}</option>
              ))}
            </select>
            {fieldError('time') && (
              <span id="time-error" className="error-msg" role="alert">{errors.time}</span>
            )}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="guests">Number of Guests <span aria-hidden="true">*</span></label>
            <div className="guest-counter" role="group" aria-label="Number of guests">
              <button
                type="button"
                className="counter-btn"
                onClick={() => handleGuestChange(-1)}
                aria-label="Decrease guests"
                disabled={formData.guests <= 1}
              >−</button>
              <input
                id="guests"
                name="guests"
                type="number"
                value={formData.guests}
                min="1"
                max="10"
                onChange={handleChange}
                onBlur={handleBlur}
                aria-required="true"
                aria-describedby={fieldError('guests') ? 'guests-error' : undefined}
                aria-invalid={!!fieldError('guests')}
                className={fieldError('guests') ? 'input-error' : ''}
                readOnly
              />
              <button
                type="button"
                className="counter-btn"
                onClick={() => handleGuestChange(1)}
                aria-label="Increase guests"
                disabled={formData.guests >= 10}
              >+</button>
            </div>
            {fieldError('guests') && (
              <span id="guests-error" className="error-msg" role="alert">{errors.guests}</span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="occasion">Occasion</label>
            <select
              id="occasion"
              name="occasion"
              value={formData.occasion}
              onChange={handleChange}
            >
              <option value="">None / Regular visit</option>
              <option value="Birthday">Birthday</option>
              <option value="Anniversary">Anniversary</option>
              <option value="Business">Business Dinner</option>
              <option value="Date Night">Date Night</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        <div className="form-group full-width">
          <label htmlFor="specialRequests">Special Requests</label>
          <textarea
            id="specialRequests"
            name="specialRequests"
            value={formData.specialRequests}
            onChange={handleChange}
            placeholder="Allergies, accessibility needs, high chair, etc."
            rows={3}
          />
        </div>
      </fieldset>

      <button
        type="submit"
        className="btn-submit"
        disabled={isSubmitting}
        aria-busy={isSubmitting}
      >
        {isSubmitting ? 'Confirming…' : 'Confirm Reservation'}
      </button>

      <p className="form-note">Fields marked with * are required.</p>
    </form>
  );
}

export default BookingForm;
