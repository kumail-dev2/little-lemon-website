import React from 'react';
import './SimplePage.css';

function AboutPage() {
  return (
    <section className="simple-page">
      <div className="simple-hero">
        <h1>About Little Lemon</h1>
        <p>A family story rooted in Mediterranean tradition.</p>
      </div>
      <div className="about-full">
        <img
          src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80"
          alt="Interior of Little Lemon restaurant"
          className="about-full-img"
        />
        <div className="about-full-text">
          <h2>Our Story</h2>
          <p>
            Little Lemon is owned by two Italian brothers, Mario and Adrian, who moved to the
            United States to pursue their shared dream of opening a restaurant. To craft an
            eatery that combines fresh, seasonal ingredients with Mediterranean traditions,
            they chose Chicago's vibrant River North neighbourhood.
          </p>
          <p>
            Since opening in 2010, Little Lemon has been a beloved neighbourhood staple,
            known for its warm hospitality, handcrafted dishes, and commitment to sustainability.
            We partner with local farms and purveyors to bring you the freshest ingredients every day.
          </p>
          <h2>Our Promise</h2>
          <p>
            Every dish at Little Lemon is made with love, care, and the finest ingredients.
            Whether you're joining us for a romantic dinner or a family celebration, we promise
            an experience that nourishes both the body and the spirit.
          </p>
        </div>
      </div>
    </section>
  );
}

export default AboutPage;
