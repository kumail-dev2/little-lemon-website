import React, { useReducer, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BookingForm from '../components/BookingForm';
import { fetchAPI, submitAPI } from '../utils/api';
import './BookingPage.css';

/**
 * Reducer for managing available times state.
 * State is lifted here (parent) and passed down as prop to BookingForm (child).
 */
function timesReducer(state, action) {
  switch (action.type) {
    case 'SET_TIMES':
      return { ...state, availableTimes: action.payload, loading: false };
    case 'LOADING':
      return { ...state, loading: true };
    default:
      return state;
  }
}

const initialState = {
  availableTimes: [],
  loading: true,
};

function BookingPage() {
  const navigate = useNavigate();
  const [state, dispatch] = useReducer(timesReducer, initialState);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  // Load times for today on mount
  useEffect(() => {
    dispatch({ type: 'LOADING' });
    fetchAPI(new Date()).then((times) => {
      dispatch({ type: 'SET_TIMES', payload: times });
    });
  }, []);

  const handleDateChange = (date) => {
    dispatch({ type: 'LOADING' });
    fetchAPI(date).then((times) => {
      dispatch({ type: 'SET_TIMES', payload: times });
    });
  };

  const handleSubmit = async (formData) => {
    setIsSubmitting(true);
    const success = await submitAPI(formData);
    setIsSubmitting(false);
    if (success) {
      navigate('/confirmed', { state: { booking: formData } });
    } else {
      alert('Something went wrong. Please try again.');
    }
  };

  return (
    <section className="booking-page">
      <div className="booking-hero">
        <h1>Book a Table</h1>
        <p>Reserve your spot at Little Lemon for a memorable dining experience.</p>
      </div>

      {state.loading ? (
        <div className="loading-indicator" aria-live="polite" aria-label="Loading available times">
          <div className="spinner" />
          <p>Loading available times…</p>
        </div>
      ) : (
        <BookingForm
          availableTimes={state.availableTimes}
          onDateChange={handleDateChange}
          onSubmit={handleSubmit}
          isSubmitting={isSubmitting}
        />
      )}
    </section>
  );
}

export default BookingPage;
