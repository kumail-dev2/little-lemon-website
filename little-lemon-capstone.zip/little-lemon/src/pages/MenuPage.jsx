import React from 'react';
import './SimplePage.css';

const menuItems = {
  Starters: [
    { name: 'Bruschetta', price: '$5.99', desc: 'Grilled bread with garlic, tomatoes, and fresh basil.' },
    { name: 'Hummus Plate', price: '$7.99', desc: 'House-made hummus with warm pita and olive oil.' },
    { name: 'Calamari Fritti', price: '$9.99', desc: 'Crispy fried calamari with lemon aioli.' },
  ],
  Mains: [
    { name: 'Greek Salad', price: '$12.99', desc: 'Crispy lettuce, peppers, olives, and Chicago-style feta.' },
    { name: 'Grilled Sea Bass', price: '$24.99', desc: 'Pan-seared with lemon butter and herbs.' },
    { name: 'Lamb Chops', price: '$28.99', desc: 'Marinated and grilled to perfection, served with tzatziki.' },
    { name: 'Pasta Pomodoro', price: '$14.99', desc: 'Fresh pasta in house-made San Marzano tomato sauce.' },
  ],
  Desserts: [
    { name: 'Lemon Dessert', price: '$5.00', desc: 'Creamy lemon cheesecake with a graham cracker crust.' },
    { name: 'Baklava', price: '$6.00', desc: 'Layers of filo, honey, and mixed nuts.' },
    { name: 'Tiramisu', price: '$6.50', desc: 'Classic Italian tiramisu dusted with cocoa powder.' },
  ],
};

function MenuPage() {
  return (
    <section className="simple-page">
      <div className="simple-hero">
        <h1>Our Menu</h1>
        <p>Fresh Mediterranean flavours, crafted daily.</p>
      </div>
      {Object.entries(menuItems).map(([category, items]) => (
        <div key={category} className="menu-category">
          <h2>{category}</h2>
          <div className="menu-items">
            {items.map(item => (
              <div key={item.name} className="menu-item">
                <div className="menu-item-header">
                  <h3>{item.name}</h3>
                  <span className="menu-price">{item.price}</span>
                </div>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}

export default MenuPage;
