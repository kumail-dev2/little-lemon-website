import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css';

const specials = [
  {
    id: 1,
    name: 'Greek Salad',
    price: '$12.99',
    desc: 'The famous greek salad of crispy lettuce, peppers, olives and our Chicago-style feta cheese, garnished with crunchy garlic and rosemary croutons.',
    img: 'https://images.unsplash.com/photo-1551248429-40975aa4de74?w=400&q=80',
    alt: 'Fresh Greek salad with feta and olives',
  },
  {
    id: 2,
    name: 'Bruschetta',
    price: '$5.99',
    desc: 'Our Bruschetta is made from grilled bread that has been smeared with garlic and seasoned with salt and olive oil. Topped with tomatoes and grilled vegetables.',
    img: 'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=400&q=80',
    alt: 'Bruschetta topped with tomatoes on grilled bread',
  },
  {
    id: 3,
    name: 'Lemon Dessert',
    price: '$5.00',
    desc: "Everyone's favourite! Ingredients: Cream Cheese, Butter, Sugar, Vanilla Extract, Lemon, Lime, Eggs, Flour, Graham Crackers.",
    img: 'https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?w=400&q=80',
    alt: 'Slice of lemon cheesecake',
  },
];

const testimonials = [
  { id: 1, name: 'Maria G.', rating: 5, text: 'Absolutely divine food and wonderful atmosphere. Will definitely return!' },
  { id: 2, name: 'James T.', rating: 5, text: 'Best Mediterranean in the city. The Greek salad is unmatched.' },
  { id: 3, name: 'Priya S.', rating: 4, text: 'Loved the lemon dessert. The staff were so friendly and welcoming.' },
  { id: 4, name: 'Carlos M.', rating: 5, text: 'Perfect date night spot. Cozy, elegant, and the food is spectacular.' },
];

function StarRating({ count }) {
  return (
    <div className="stars" aria-label={`${count} out of 5 stars`}>
      {[1,2,3,4,5].map(i => (
        <span key={i} className={i <= count ? 'star filled' : 'star'} aria-hidden="true">★</span>
      ))}
    </div>
  );
}

function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="hero" aria-label="Little Lemon hero">
        <div className="hero-content">
          <h1 className="hero-title">Little Lemon</h1>
          <p className="hero-location">Chicago</p>
          <p className="hero-desc">
            We are a family-owned Mediterranean restaurant, focused on traditional recipes
            served with a modern twist. Fresh ingredients, bold flavours.
          </p>
          <Link to="/booking" className="btn-hero">Reserve a Table</Link>
        </div>
        <div className="hero-image" aria-hidden="true" />
      </section>

      {/* Specials */}
      <section className="specials-section" aria-labelledby="specials-heading">
        <div className="specials-header">
          <h2 id="specials-heading">This Week's Specials!</h2>
          <Link to="/menu" className="btn-outline">Online Menu</Link>
        </div>
        <div className="specials-grid">
          {specials.map(item => (
            <article key={item.id} className="special-card">
              <figure className="special-img">
                <img src={item.img} alt={item.alt} loading="lazy" />
              </figure>
              <div className="special-body">
                <div className="special-title-row">
                  <h3>{item.name}</h3>
                  <span className="special-price">{item.price}</span>
                </div>
                <p>{item.desc}</p>
                <Link to="/menu" className="btn-text">Order a delivery →</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="testimonials-section" aria-labelledby="testimonials-heading">
        <h2 id="testimonials-heading">What Our Customers Say</h2>
        <div className="testimonials-grid">
          {testimonials.map(t => (
            <article key={t.id} className="testimonial-card">
              <StarRating count={t.rating} />
              <p className="testimonial-text">"{t.text}"</p>
              <p className="testimonial-name">— {t.name}</p>
            </article>
          ))}
        </div>
      </section>

      {/* About snippet */}
      <section className="about-snippet" aria-labelledby="about-heading">
        <div className="about-content">
          <div className="about-text">
            <h2 id="about-heading">Little Lemon</h2>
            <h3>Chicago</h3>
            <p>
              Little Lemon is owned by two Italian brothers, Mario and Adrian, who moved to the
              United States to pursue their shared dream of owning a restaurant. To craft an
              eatery that combines fresh, seasonal ingredients with Mediterranean traditions,
              they settled in Chicago's bustling River North neighbourhood.
            </p>
          </div>
          <div className="about-images">
            <img
              src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=300&q=80"
              alt="Chef preparing food"
              className="about-img about-img--top"
              loading="lazy"
            />
            <img
              src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=300&q=80"
              alt="Restaurant interior"
              className="about-img about-img--bottom"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  );
}

export default HomePage;
