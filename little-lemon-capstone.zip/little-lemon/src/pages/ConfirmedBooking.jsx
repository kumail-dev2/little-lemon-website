import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import './ConfirmedBooking.css';

function ConfirmedBooking() {
  const location = useLocation();
  const booking = location.state?.booking;

  const ref = `LL-${Math.random().toString(36).substr(2, 8).toUpperCase()}`;

  return (
    <section className="confirmed-page" aria-live="polite">
      <div className="confirmed-card">
        <div className="confirmed-icon" aria-hidden="true">✓</div>
        <h1>Reservation Confirmed!</h1>
        <p className="confirmed-ref">Booking Reference: <strong>{ref}</strong></p>

        {booking && (
          <div className="confirmed-details">
            <h2>Your Booking Summary</h2>
            <ul>
              <li><span>Name:</span> {booking.firstName} {booking.lastName}</li>
              <li><span>Email:</span> {booking.email}</li>
              {booking.phone && <li><span>Phone:</span> {booking.phone}</li>}
              <li><span>Date:</span> {new Date(booking.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</li>
              <li><span>Time:</span> {booking.time}</li>
              <li><span>Guests:</span> {booking.guests}</li>
              {booking.occasion && <li><span>Occasion:</span> {booking.occasion}</li>}
              {booking.specialRequests && <li><span>Special Requests:</span> {booking.specialRequests}</li>}
            </ul>
          </div>
        )}

        <p className="confirmed-note">
          A confirmation email has been sent to {booking?.email || 'your email address'}.
          We look forward to seeing you!
        </p>

        <Link to="/" className="btn-home">Back to Home</Link>
      </div>
    </section>
  );
}

export default ConfirmedBooking;
