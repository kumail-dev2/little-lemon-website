/**
 * Seeded pseudo-random generator for consistent available times per date.
 */
function seededRandom(seed) {
  const x = Math.sin(seed + 1) * 10000;
  return x - Math.floor(x);
}

/**
 * fetchAPI – returns a list of available time slots for a given date.
 * Simulates an async API call. Some slots are randomly unavailable.
 * @param {Date} date
 * @returns {Promise<string[]>}
 */
export function fetchAPI(date) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const allSlots = [
        '17:00', '17:30', '18:00', '18:30',
        '19:00', '19:30', '20:00', '20:30',
        '21:00', '21:30',
      ];

      const seed = date instanceof Date
        ? date.getFullYear() * 10000 + (date.getMonth() + 1) * 100 + date.getDate()
        : 20240101;

      const available = allSlots.filter((_, i) => seededRandom(seed + i) > 0.25);
      resolve(available.length > 0 ? available : ['18:00', '19:00', '20:00']);
    }, 300);
  });
}

/**
 * submitAPI – simulates submitting a booking.
 * Returns true on success (90% of the time), false otherwise.
 * @param {Object} formData
 * @returns {Promise<boolean>}
 */
export function submitAPI(formData) {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log('Booking submitted:', formData);
      resolve(Math.random() > 0.1); // 90% success rate
    }, 500);
  });
}
